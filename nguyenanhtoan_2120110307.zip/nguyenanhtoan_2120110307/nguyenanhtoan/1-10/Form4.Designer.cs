﻿
namespace _1_10
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hienthi = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.bt7 = new System.Windows.Forms.Button();
            this.bt8 = new System.Windows.Forms.Button();
            this.bt9 = new System.Windows.Forms.Button();
            this.btchia = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.bt4 = new System.Windows.Forms.Button();
            this.bt5 = new System.Windows.Forms.Button();
            this.bt6 = new System.Windows.Forms.Button();
            this.btnhan = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.bt1 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.bttru = new System.Windows.Forms.Button();
            this.btbang = new System.Windows.Forms.Button();
            this.bt0 = new System.Windows.Forms.Button();
            this.btcham = new System.Windows.Forms.Button();
            this.btcong = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // hienthi
            // 
            this.hienthi.Location = new System.Drawing.Point(9, 10);
            this.hienthi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.hienthi.Multiline = true;
            this.hienthi.Name = "hienthi";
            this.hienthi.Size = new System.Drawing.Size(349, 71);
            this.hienthi.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button1.Location = new System.Drawing.Point(9, 93);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "MC";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button2.Location = new System.Drawing.Point(80, 93);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(66, 42);
            this.button2.TabIndex = 2;
            this.button2.Text = "MR";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button3.Location = new System.Drawing.Point(150, 93);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(66, 42);
            this.button3.TabIndex = 3;
            this.button3.Text = "MS";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button4.Location = new System.Drawing.Point(220, 93);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(66, 42);
            this.button4.TabIndex = 4;
            this.button4.Text = "M+";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button5.Location = new System.Drawing.Point(291, 93);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(66, 42);
            this.button5.TabIndex = 5;
            this.button5.Text = "M-";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button6.Location = new System.Drawing.Point(9, 141);
            this.button6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(66, 42);
            this.button6.TabIndex = 6;
            this.button6.Text = "←";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button7.Location = new System.Drawing.Point(80, 141);
            this.button7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(66, 42);
            this.button7.TabIndex = 7;
            this.button7.Text = "CE";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button8.Location = new System.Drawing.Point(150, 141);
            this.button8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(66, 42);
            this.button8.TabIndex = 8;
            this.button8.Text = "C";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button9.Location = new System.Drawing.Point(220, 141);
            this.button9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(66, 42);
            this.button9.TabIndex = 9;
            this.button9.Text = "±";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button10.Location = new System.Drawing.Point(291, 141);
            this.button10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(66, 42);
            this.button10.TabIndex = 10;
            this.button10.Text = "√";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // bt7
            // 
            this.bt7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt7.Location = new System.Drawing.Point(9, 188);
            this.bt7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt7.Name = "bt7";
            this.bt7.Size = new System.Drawing.Size(66, 42);
            this.bt7.TabIndex = 11;
            this.bt7.Text = "7";
            this.bt7.UseVisualStyleBackColor = true;
            this.bt7.Click += new System.EventHandler(this.bt7_Click);
            // 
            // bt8
            // 
            this.bt8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt8.Location = new System.Drawing.Point(80, 188);
            this.bt8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt8.Name = "bt8";
            this.bt8.Size = new System.Drawing.Size(66, 42);
            this.bt8.TabIndex = 12;
            this.bt8.Text = "8";
            this.bt8.UseVisualStyleBackColor = true;
            this.bt8.Click += new System.EventHandler(this.bt8_Click);
            // 
            // bt9
            // 
            this.bt9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt9.Location = new System.Drawing.Point(150, 188);
            this.bt9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt9.Name = "bt9";
            this.bt9.Size = new System.Drawing.Size(66, 42);
            this.bt9.TabIndex = 13;
            this.bt9.Text = "9";
            this.bt9.UseVisualStyleBackColor = true;
            this.bt9.Click += new System.EventHandler(this.bt9_Click);
            // 
            // btchia
            // 
            this.btchia.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btchia.Location = new System.Drawing.Point(220, 188);
            this.btchia.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btchia.Name = "btchia";
            this.btchia.Size = new System.Drawing.Size(66, 42);
            this.btchia.TabIndex = 14;
            this.btchia.Text = "/";
            this.btchia.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button15.Location = new System.Drawing.Point(291, 188);
            this.button15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(66, 42);
            this.button15.TabIndex = 15;
            this.button15.Text = "%";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // bt4
            // 
            this.bt4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt4.Location = new System.Drawing.Point(9, 235);
            this.bt4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(66, 42);
            this.bt4.TabIndex = 16;
            this.bt4.Text = "4";
            this.bt4.UseVisualStyleBackColor = true;
            this.bt4.Click += new System.EventHandler(this.bt4_Click);
            // 
            // bt5
            // 
            this.bt5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt5.Location = new System.Drawing.Point(80, 235);
            this.bt5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt5.Name = "bt5";
            this.bt5.Size = new System.Drawing.Size(66, 42);
            this.bt5.TabIndex = 17;
            this.bt5.Text = "5";
            this.bt5.UseVisualStyleBackColor = true;
            this.bt5.Click += new System.EventHandler(this.bt5_Click);
            // 
            // bt6
            // 
            this.bt6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt6.Location = new System.Drawing.Point(150, 235);
            this.bt6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt6.Name = "bt6";
            this.bt6.Size = new System.Drawing.Size(66, 42);
            this.bt6.TabIndex = 18;
            this.bt6.Text = "6";
            this.bt6.UseVisualStyleBackColor = true;
            this.bt6.Click += new System.EventHandler(this.bt6_Click);
            // 
            // btnhan
            // 
            this.btnhan.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnhan.Location = new System.Drawing.Point(220, 235);
            this.btnhan.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnhan.Name = "btnhan";
            this.btnhan.Size = new System.Drawing.Size(66, 42);
            this.btnhan.TabIndex = 19;
            this.btnhan.Text = "*";
            this.btnhan.UseVisualStyleBackColor = true;
            this.btnhan.Click += new System.EventHandler(this.btnhan_Click);
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button20.Location = new System.Drawing.Point(291, 235);
            this.button20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(66, 42);
            this.button20.TabIndex = 20;
            this.button20.Text = "1/x";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // bt1
            // 
            this.bt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt1.Location = new System.Drawing.Point(9, 282);
            this.bt1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(66, 42);
            this.bt1.TabIndex = 21;
            this.bt1.Text = "1";
            this.bt1.UseVisualStyleBackColor = true;
            this.bt1.Click += new System.EventHandler(this.bt1_Click);
            // 
            // bt2
            // 
            this.bt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt2.Location = new System.Drawing.Point(80, 282);
            this.bt2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(66, 42);
            this.bt2.TabIndex = 22;
            this.bt2.Text = "2";
            this.bt2.UseVisualStyleBackColor = true;
            this.bt2.Click += new System.EventHandler(this.bt2_Click);
            // 
            // bt3
            // 
            this.bt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt3.Location = new System.Drawing.Point(150, 282);
            this.bt3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(66, 42);
            this.bt3.TabIndex = 23;
            this.bt3.Text = "3";
            this.bt3.UseVisualStyleBackColor = true;
            this.bt3.Click += new System.EventHandler(this.bt3_Click);
            // 
            // bttru
            // 
            this.bttru.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bttru.Location = new System.Drawing.Point(220, 282);
            this.bttru.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bttru.Name = "bttru";
            this.bttru.Size = new System.Drawing.Size(66, 42);
            this.bttru.TabIndex = 24;
            this.bttru.Text = "-";
            this.bttru.UseVisualStyleBackColor = true;
            this.bttru.Click += new System.EventHandler(this.bttru_Click);
            // 
            // btbang
            // 
            this.btbang.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btbang.Location = new System.Drawing.Point(291, 282);
            this.btbang.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btbang.Name = "btbang";
            this.btbang.Size = new System.Drawing.Size(66, 89);
            this.btbang.TabIndex = 25;
            this.btbang.Text = "=";
            this.btbang.UseVisualStyleBackColor = true;
            // 
            // bt0
            // 
            this.bt0.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt0.Location = new System.Drawing.Point(9, 329);
            this.bt0.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt0.Name = "bt0";
            this.bt0.Size = new System.Drawing.Size(136, 42);
            this.bt0.TabIndex = 26;
            this.bt0.Text = "0";
            this.bt0.UseVisualStyleBackColor = true;
            this.bt0.Click += new System.EventHandler(this.bt0_Click);
            // 
            // btcham
            // 
            this.btcham.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btcham.Location = new System.Drawing.Point(150, 329);
            this.btcham.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btcham.Name = "btcham";
            this.btcham.Size = new System.Drawing.Size(66, 42);
            this.btcham.TabIndex = 27;
            this.btcham.Text = ".";
            this.btcham.UseVisualStyleBackColor = true;
            this.btcham.Click += new System.EventHandler(this.btcham_Click);
            // 
            // btcong
            // 
            this.btcong.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btcong.Location = new System.Drawing.Point(220, 329);
            this.btcong.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btcong.Name = "btcong";
            this.btcong.Size = new System.Drawing.Size(66, 42);
            this.btcong.TabIndex = 28;
            this.btcong.Text = "+";
            this.btcong.UseVisualStyleBackColor = true;
            this.btcong.Click += new System.EventHandler(this.Btcong_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 381);
            this.Controls.Add(this.btcong);
            this.Controls.Add(this.btcham);
            this.Controls.Add(this.bt0);
            this.Controls.Add(this.btbang);
            this.Controls.Add(this.bttru);
            this.Controls.Add(this.bt3);
            this.Controls.Add(this.bt2);
            this.Controls.Add(this.bt1);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.btnhan);
            this.Controls.Add(this.bt6);
            this.Controls.Add(this.bt5);
            this.Controls.Add(this.bt4);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.btchia);
            this.Controls.Add(this.bt9);
            this.Controls.Add(this.bt8);
            this.Controls.Add(this.bt7);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.hienthi);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox hienthi;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button bt7;
        private System.Windows.Forms.Button bt8;
        private System.Windows.Forms.Button bt9;
        private System.Windows.Forms.Button btchia;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button bt4;
        private System.Windows.Forms.Button bt5;
        private System.Windows.Forms.Button bt6;
        private System.Windows.Forms.Button btnhan;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button bt1;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button bttru;
        private System.Windows.Forms.Button btbang;
        private System.Windows.Forms.Button bt0;
        private System.Windows.Forms.Button btcham;
        private System.Windows.Forms.Button btcong;
    }
}