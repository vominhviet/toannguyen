﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1_10
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        double data1, data2;
        string pheptinh;
        private void Form4_Load(object sender, EventArgs e)
        {

        }

       
        private void btnhan_Click(object sender, EventArgs e)
        {
            pheptinh = "nhan";
            hienthi.Text = data1.ToString() + " * ";
            hienthi.Clear();
        }
        private void bt0_Click(object sender, EventArgs e)

        {

            hienthi.Text = hienthi.Text + "0";
        }
        private void bt1_Click(object sender, EventArgs e)

        {

            hienthi.Text = hienthi.Text + "1";
        }

        private void bt2_Click(object sender, EventArgs e)
        {

            hienthi.Text = hienthi.Text + "2";
        }

        private void bt3_Click(object sender, EventArgs e)
        {

            hienthi.Text = hienthi.Text + "3";
        }

        private void bt4_Click(object sender, EventArgs e)
        {

            hienthi.Text = hienthi.Text + "4";
        }

        private void bt5_Click(object sender, EventArgs e)
        {

            hienthi.Text = hienthi.Text + "5";
        }

        private void bt6_Click(object sender, EventArgs e)
        {
            hienthi.Text = hienthi.Text + "6";
        }

        private void bt7_Click(object sender, EventArgs e)
        {
            hienthi.Text = hienthi.Text + "7";
        }

        private void bt8_Click(object sender, EventArgs e)
        {

            hienthi.Text = hienthi.Text + "8";
        }

        private void bt9_Click(object sender, EventArgs e)
        {

            hienthi.Text = hienthi.Text + "9";
        }

        private void btcham_Click(object sender, EventArgs e)
        {
            hienthi.Text = hienthi.Text + ".";
        }

        private void button_Click(object sender, EventArgs e)
        {
            hienthi.Clear();
   
        }

        private void btcong_Click(object sender, EventArgs e)
        {
            if (pheptinh == "cong")
            {
                hienthi.Text = data1.ToString() + " + " + float.Parse(hienthi.Text) + " = ";
                data2 = data1 + float.Parse(hienthi.Text);
                hienthi.Text = data2.ToString();
                hienthi.Text = data1.ToString() + "-";
                data1 = float.Parse(hienthi.Text);
                hienthi.Clear();
            }
        }

        private void bttru_Click(object sender, EventArgs e)
        {
            pheptinh = "tru";
            hienthi.Text = data1.ToString() + " - ";
            hienthi.Text = data2.ToString();
            hienthi.Clear();
        }

        private void btchia_Click(object sender, EventArgs e)
        {
            pheptinh = "chia";
            hienthi.Text = data1.ToString() + " / ";
            data2 = data1 + float.Parse(hienthi.Text);
            hienthi.Text = data2.ToString();
            hienthi.Clear();
        }

        private void hienthi_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btcong_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
