﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1_10
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

private void Form6_Load (object sender, EventArgs e)
        {
            ArrayList lst = GetData();
            cb_Faculty.DataSource = lst;
            cb_Faculty.DisplayMember = "name";
        }    
        public ArrayList GetData()
{
    ArrayList lst = new ArrayList();
    Faculty f = new Faculty();
    f.id = "K01";
    f.name = "Công nghệ thông tin";
    f.quanlity = 1200;
    lst.Add(f);
    f = new Faculty();
    f.id = "K02";
    f.name = "Điện";
    f.quanlity = 4200;
    lst.Add(f);
    f = new Faculty();
    f.id = "K03";
    f.name = "Ngoại Ngữ";
    f.quanlity = 5200;
    lst.Add(f);
    f = new Faculty();
    f.id = "K04";
    f.name = "Quản Trị Kinh Doanh";
    f.quanlity = 6200;
    lst.Add(f);
    f = new Faculty();
    f.id = "K05";
    f.name = "Quản Trị Nhà Hàng Khách Sạn";
    f.quanlity = 7200;
    lst.Add(f);
    return lst;

}
        private void button1_Click(object sender, EventArgs e)
        {
            tbDisplay.Clear();

        }

        private void cb_Faculty_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Faculty.ValueMember = "id";
            string id = cb_Faculty.SelectedValue.ToString();
            tbDisplay.Text = id;
        }

        private void bt_Click(object sender, EventArgs e)
        {
            cb_Faculty.ValueMember = "name";
            string name = cb_Faculty.SelectedValue.ToString();
            tbDisplay.Text = "Bạn đã chọn khoa có tên: " + name;
        }
     }
}
