﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _1_10
{
    
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btcong_Click(object sender, EventArgs e)
        {
            int x = int.Parse(tbsox.Text);
            int y = int.Parse(tbsoy.Text);
            int kq = x + y;
            tbketqua.Text = tbketqua.Text + x.ToString() + " + " + y.ToString() + " = "  + kq.ToString() + "\r\n";
        }
        private void btnhan_Click(object sender, EventArgs e)
        {
            int x = int.Parse(tbsox.Text);
            int y = int.Parse(tbsoy.Text);
            int kq = x * y;
            tbketqua.Text = tbketqua.Text + x.ToString() + " * " + y.ToString() + " = " + kq.ToString() + "\r\n";
        }
        private void btluu_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("Caculator.txt", true);
            sw.Write(tbketqua.Text);
            sw.Close();
        }
        private void btthoat_Click(object sender, EventArgs e)
        {
            DialogResult h = MessageBox.Show
               ("Bạn có chắc muốn thoát không?", "Error", MessageBoxButtons.OKCancel);
            if (h == DialogResult.OK)
                Application.Exit();
        }

        private void tbsoy_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
